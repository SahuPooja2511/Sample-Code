import { LightningElement, api, track, wire } from "lwc";
import getCartInformation from "@salesforce/apex/CheckoutController.getCartInformation";
import { CurrentPageReference } from "lightning/navigation";
import { registerListener, unregisterAllListeners } from "c/pubsub";
import processSubmitOrder from "@salesforce/apex/CheckoutController.processSubmitOrder";
import isOrderProcessing from "@salesforce/apex/CheckoutController.isOrderProcessing";
import addPONumber from "@salesforce/apex/CheckoutController.addPONumber";
import processActivatingOrder from "@salesforce/apex/CheckoutController.processActivatingOrder";
import getOrderSummary from "@salesforce/apex/CheckoutController.getOrderSummary";
import createAuthviaPayment from "@salesforce/apex/CheckoutController.createAuthviaPayment";
import fetchPaymentInfo from "@salesforce/apex/CheckoutController.fetchPaymentInfo";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getLinks } from "c/util";
import getSalesOrderIdByOrderId from "@salesforce/apex/OrderHistoryController.getSalesOrderIdByOrderId";
import B2B_MINIMUM_PRODUCT_TOTAL_AMOUNT from "@salesforce/label/c.B2B_MINIMUM_PRODUCT_TOTAL_AMOUNT";
import sendOrderConfirmationEmail from "@salesforce/apex/B2BSalesOrderUtility.sendOrderConfirmationEmail";
import checkPONumber from "@salesforce/apex/CheckCustomerPONumberController.checkPONumber";

const PAYMENT_METHOD_CHANGED = "paymentMethodChanged";

export default class CheckoutOrderSummary extends LightningElement {
  @wire(CurrentPageReference) pageRef;

  @api cartId;
  @api sessionId;

  @track cartInfo = {};
  poNumber = "";
  isShowTaxBreakup = false;
  confirmationModal = false;
  paymentProcessingModal = false;

  isShippingCostLoading = true;
  isTaxLoading = true;
  links = getLinks();

  customerTermsAndCondition = this.links.customerTermsAndConditions; //modified by Archit due to SB-803
  get isOrderTotalCalcualting() {
    let flag = this.isShippingCostLoading || this.isTaxLoading;
    return flag;
  }

  validatedPoints = {
    acceptTermsAndConditions: false,
    isPoNumber: false,
    isOrderLessThanCriteria: false,
    isPaymentMethodComplete: false,
    isShippingAddressComplete: false,
    isBillingAddressComplete: false,
    isShippingPreferenceComplete: false,
    isTaxCalculated: false,
    isShippingCalcualted: false,
  };

  @track errors = {
    isAcceptTermsAndConditions: false,
    isPoNumberError: false,
    isOrderLessThanCriteria: false,
    isPaymentMethodComplete: false,
    isShippingAddressComplete: false,
    isBillingAddressComplete: false,
    isShippingPreferenceComplete: false,
    isTaxCalculated: false,
    isShippingCalcualted: false,
  };

  errorMessage = {
    acceptAndTermsConditionError:
      "Please accept terms & condition to submit order.",
    poNumber: "Please add PO number before apply.", //modified by Archit due to SB-805
    amountLessThanLimit:
      "Product total amount can't be less than $" +
      B2B_MINIMUM_PRODUCT_TOTAL_AMOUNT, //modified by Archit due to SB-805
    shippingAddress:
      "Please add shipping information before proceeding with order.",
    billingAddress:
      "Please add billing information before proceeding with order.",
    shippingPreference:
      "Please add shipping preference before proceeding with order.",
    paymentMethodNotSelected:
      "Please select/add a payment method from payment infromation.",
  };

  connectedCallback() {
    this.fetchCartInformation();
    this.registerEvents();
  }

  registerEvents() {
    registerListener(PAYMENT_METHOD_CHANGED, this.validatePaymentMethod, this);
  }

  isError = false;
  totalTransactionCount = 0;

  // Added by Archit due to SB-878
  isDraftPONumber = false;
  cartDeliveryGroup;
  // Modified by Archit due to SB-878
  @api
  fetchCartInformation() {
    this.totalTransactionCount++;

    getCartInformation({ cartId: this.cartId })
      .then((result) => {
        this.cartInfo = result.cartInfo;
        this.cartDeliveryGroup = result.deliveryGroup;
        this.isTaxLoading = this.cartInfo.Is_Tax_Need_To_Calculate__c;
        this.isShippingCostLoading =
          this.cartInfo.Is_Shipping_Cost_Need_To_Calculate__c;

        if (!this.isDraftPONumber) {
          this.isDraftPONumber = true;
          this.poNumber =
            result.cartInfo.PoNumber == undefined
              ? ""
              : result.cartInfo.PoNumber;
        }

        if (this.isError || this.cartInfo.TotalAmount == 0) {
          this.isTaxLoading = false;
          this.isShippingCostLoading = false;
          return;
        } else if (
          !this.isError &&
          (this.isTaxLoading || this.isShippingCostLoading) &&
          this.cartInfo.TotalAmount > 0
        ) {
          setTimeout(() => {
            this.fetchCartInformation();
          }, 3000);
        } else {
          this.resetErrors();
          this.validatedPoints.isOrderLessThanCriteria =
            this.isOrderLessThanCriteria();
          this.validatedPoints.isPaymentMethodComplete = this.cartInfo
            .Authvia_Payment_Method_ID__c
            ? true
            : false;
          this.validatedPoints.isPaymentMethodComplete = this.cartInfo
            .Authvia_Payment_Method_ID__c
            ? true
            : false;
          this.validatedPoints.isBillingAddressComplete =
            this.cartInfo.Contact_Point_Address__c &&
              this.cartInfo.Contact_Point_Address__c != ""
              ? true
              : false;
          this.validatedPoints.isShippingAddressComplete = this
            .cartDeliveryGroup.DeliverToCountry
            ? true
            : false;

          if (this.cartDeliveryGroup.DeliveryMethodId) {
            this.validatedPoints.isShippingPreferenceComplete = true;
          } else if (
            this.cartInfo.Shipping_Option__c &&
            this.cartInfo.Shipping_Option_Value__c
          ) {
            this.validatedPoints.isShippingPreferenceComplete = true;
          }

          if (this.totalTransactionCount < 6) {
            this.totalTransactionCount = 5;
            setTimeout(() => {
              this.fetchCartInformation();
            }, 3000);
          } else {
            this.totalTransactionCount = 0;
          }
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  /**
   * @author : Archit
   * @reason : SB-869
   * @returns True if order less than minimum criteria else false
   */
  isOrderLessThanCriteria() {
    let isOrderLessThan = true;
    try {
      isOrderLessThan =
        this.cartInfo.TotalProductAmount <
        Number(B2B_MINIMUM_PRODUCT_TOTAL_AMOUNT);
    } catch (error) {
      console.log("error", error);
    }
    return isOrderLessThan;
  }

  validatePaymentMethod() {
    console.log("validatePaymentMethod");
    getCartInformation({ cartId: this.cartId }).then((result) => {
      this.errors.isPaymentMethodComplete = false;
      this.validatedPoints.isPaymentMethodComplete = result.cartInfo
        .Authvia_Payment_Method_ID__c
        ? true
        : false;
    });
  }

  resetErrors() {
    this.errors = {
      isAcceptTermsAndConditions: false,
      isPoNumberError: false,
      isOrderLessThanCriteria: false,
      isPaymentMethodComplete: false,
    };
  }

  @api
  setError() {
    this.isError = true;
  }

  // Modified by Archit due to SB-883
  handlePoNumber(event) {
    this.isDraftPONumber = true;

    this.poNumber = event.target.value;

    if (this.errors.isPoNumberError) {
      this.errors.isPoNumberError = false;
    }
  }

  handleAcceptTermsAndCondition() {
    this.validatedPoints.acceptTermsAndConditions =
      !this.validatedPoints.acceptTermsAndConditions;
    if (this.errors.isAcceptTermsAndConditions) {
      this.errors.isAcceptTermsAndConditions = false;
    }
  }

  // Modified by Archit due to SB-871
  isShowPONumberIssue = false;

  async handleApplyPoNumber() {
    if (!this.poNumber || this.poNumber == undefined || this.poNumber == "") {
      this.errors.isPoNumberError = true;
      return;
    } else {
      await checkPONumber({
        pONumber: this.poNumber,
      })
        .then((result) => {
          if (result) {
            this.isShowPONumberIssue = true;
          } else {
            this.isShowPONumberIssue = false;
          }
        })
        .catch((error) => {
          console.log("checkPONumber", error);
          this.isShowPONumberIssue = false;
        });

      if (!this.isShowPONumberIssue) {
        this.isShowPONumberIssue = false;
        this.errors.isPoNumberError = false; //added by Archit due to SB-656
        this.handleAddPONumber();
      }
    }
  }

  handleAddPONumber() {
    addPONumber({
      cartId: this.cartId,
      sessionId: this.sessionId,
      PoNumber: this.poNumber,
    })
      .then((result) => {
        this.cartInfo.PoNumber = this.poNumber;
        //Added by Archit for SB-881
        const eventMessage = new ShowToastEvent({
          title: "Success",
          message: "PO Number applied successfully.",
          variant: "success",
        });
        this.dispatchEvent(eventMessage);
      })
      .catch((error) => {
        console.log("handleAddPONumber.error", error);
      });
  }

  // Submit Order Methods Section
  handleSubmitOrder() {
    if (this.validateOrder()) {
      this.confirmationModal = true;
    } else {
      //Order Not Validated.
      return;
    }
  }
  orderLoading = false;
  proceedWithOrder() {
    processSubmitOrder({
      cartId: this.cartId,
      sessionId: this.sessionId,
      cartDeliveryGroupId: this.cartDeliveryGroup.Id,
    })
      .then((result) => {
        if (result == "success") {
          this.checkOrderProcessing("Payments And Billing Address");
        } else if (result == "Processing") {
          setTimeout(() => {
            this.fetchCartShippingCostInfo();
          }, 1000);
        } else if (result == "Error") {
          console.log("processSubmitOrder.Error");
          this.OrderProcessData.isError = true;
        }
      })
      .catch((error) => {
        console.log("proceedWithOrder.error", error);
      });
  }

  checkOrderProcessing(_requiredState) {
    isOrderProcessing({
      cartId: this.cartId,
      sessionId: this.sessionId,
      requiredState: _requiredState,
    })
      .then((result) => {
        if (result == "success") {
          if (_requiredState == "Payments And Billing Address") {
            this.processPaymentsAndBillings();
          }
        } else if (result == "Processing") {
          setTimeout(() => {
            this.checkOrderProcessing(_requiredState);
          }, 1500);
        } else if (result == "Error") {
          this.OrderProcessData.isError = true;
        }
      })
      .catch((error) => {
        this.OrderProcessData.isError = true;
        this.OrderProcessData.errorMessage = error.body.message;
      });
  }

  processPaymentsAndBillings() {
    this.processActivatingOrder();
  }

  processActivatingOrder() {
    processActivatingOrder({ cartId: this.cartId, sessionId: this.sessionId })
      .then((result) => {
        this.OrderProcessData.isOrderCreated = true;
        this.OrderProcessData.orderId = result.split("-")[1];
        this.fetchOrderSummary();
      })
      .catch((error) => { });
  }

  fetchOrderSummary() {
    getOrderSummary({ cartId: this.cartId, sessionId: this.sessionId })
      .then((result) => {
        if (result == "Processing") {
          setTimeout(() => {
            this.fetchOrderSummary();
          }, 1000);
        } else if (result == "Not found") {
          setTimeout(() => {
            this.fetchOrderSummary();
          }, 1000);
        } else {
          this.fetchSalesOrderId();
          this.orderLoading = false;
        }
      })
      .catch((error) => { });
  }

  validateOrder() {
    let isValid = true;

    if (!this.validatedPoints.acceptTermsAndConditions) {
      this.errors.isAcceptTermsAndConditions = true;
      isValid = false;
    } else if (!this.cartInfo.PoNumber) {
      if (!this.poNumber || this.poNumber == undefined || this.poNumber == "") {
        this.errorMessage.poNumber = "Please add PO number before submit."; //modified by Archit due to SB-656 //modified by Archit due to SB-805
      } else {
        this.errorMessage.poNumber =
          "Please apply PO number before submit order."; //modified by Archit due to SB-805
      }
      this.errors.isPoNumberError = true;
      isValid = false;
    } else if (this.validatedPoints.isOrderLessThanCriteria) {
      this.errors.isOrderLessThanCriteria = true;
      isValid = false;
    } else if (!this.validatedPoints.isShippingAddressComplete) {
      this.errors.isShippingAddressComplete = true;
      isValid = false;
    } else if (!this.validatedPoints.isShippingPreferenceComplete) {
      this.errors.isShippingPreferenceComplete = true;
      isValid = false;
    } else if (!this.validatedPoints.isBillingAddressComplete) {
      this.errors.isBillingAddressComplete = true;
      isValid = false;
    } else if (!this.validatedPoints.isPaymentMethodComplete) {
      this.errors.isPaymentMethodComplete = true;
      isValid = false;
    }
    return isValid;
    // It will validate the complete order that everything is got from user.
  }

  handleConfirmationCancel() {
    this.confirmationModal = false;
    this.paymentProcessingModal = false;
  }

  showPaymentProcessingScreen = false;
  isPaymentDone = false;
  Authvia_Payment_Id__c = undefined;
  handleContinueAndProceedWithPayment() {
    this.isPaymentDone = false;
    this.showPaymentProcessingScreen = true;
    console.log("handleContinueAndProceedWithPayment starting");
    this.confirmationModal = false;
    this.paymentProcessingModal = true;
    createAuthviaPayment({ cartId: this.cartId, paymentMode: "Auto Pay" })
      .then((result) => {
        console.log("createAuthviaPayment.result", result);
        this.cartInfo = result;
        this.Authvia_Payment_Id__c = result.Authvia_Payment_Id__c;
        this.fetchPaymentInfoAsync();
        this.proceedWithOrder(); //Added by Archit For SB-860
      })
      .catch((error) => {
        console.log("createAuthviaPayment.error", error);
      });
  }

  showPaymentStatusScreen = false;
  showStatusMessage = false;
  statusMessage = "Please wait...";

  fetchCounts = 0;
  maxLimitCount = 10;
  fetchPaymentInfoAsync() {
    this.fetchCounts++;
    let isNeedRecall = true;
    fetchPaymentInfo({ authviaPaymentId: this.cartInfo.Authvia_Payment_Id__c })
      .then((result1) => {
        const paymentInfo = result1;
        console.log("fetchPaymentInfo.paymentInfo", paymentInfo);
        if (
          paymentInfo.AVPAY__Payment_Status__c &&
          paymentInfo.AVPAY__Payment_Status__c == "Request Sent"
        ) {
          this.showPaymentProcessingScreen = true;
        } else if (
          paymentInfo.AVPAY__Payment_Status__c &&
          paymentInfo.AVPAY__Payment_Status__c == "Approved/Paid"
        ) {
          this.statusMessage =
            "Your payment is completed. Please click on done to complete your order.";
          isNeedRecall = false;
          this.paymentProcessingModal = false;
          const eventMessage = new ShowToastEvent({
            title: "Success",
            message: "Your order successfully completed",
            variant: "success",
          });
          this.handleConfirmationOk();
          this.dispatchEvent(eventMessage);
        } else if (
          paymentInfo.AVPAY__Payment_Status__c &&
          (paymentInfo.AVPAY__Payment_Status__c == "Declined" ||
            paymentInfo.AVPAY__Payment_Status__c == "Canceled")
        ) {
          this.statusMessage =
            "Your payment is failed. We can't process your order.";
          this.isPaymentDone = false;
          this.showPaymentStatusScreen = true;
        }
        if (isNeedRecall) {
          if (this.fetchCounts < this.maxLimitCount) {
            setTimeout(() => {
              this.fetchPaymentInfoAsync();
            }, 5000);
          } else {
            this.handleConfirmationOk();
            this.paymentProcessingModal = false;
            const eventMessage = new ShowToastEvent({
              title: "Success",
              message:
                "Your order successfully created but payment not done yet. We will review payment status later.",
              variant: "success",
            });
            this.dispatchEvent(eventMessage);
          }
        }
      })
      .catch((error) => {
        console.log("fetchPaymentInfo.error", error);
      });
  }

  OrderProcessData = {
    isOrderCreated: false,
    isSoCreated: false,
    orderId: undefined,
    soId: undefined,
    isError: false,
    errorMessage: undefined,
  };
  confirmationCount = 0;
  handleConfirmationOk() {
    this.orderLoading = true;
    this.confirmationModal = false;
    if (
      this.OrderProcessData.isSoCreated == true &&
      this.OrderProcessData.soId
    ) {
      let url = this.links.Order_Confirmation + this.OrderProcessData.soId;
      window.open(url, "_self");
      //Added by Archit as per SB-880 & SB-873
      sendOrderConfirmationEmail({ salesOrderId: this.salesOrderId })
        .then((data) => { })
        .catch((error) => { });
    } else if (
      this.OrderProcessData.isOrderCreated &&
      this.confirmationCount <= 3
    ) {
      this.fetchSalesOrderId();
      setTimeout(() => {
        this.handleConfirmationOk();
      }, 3000);
    } else if (this.OrderProcessData.isError) {
      const eventMessage = new ShowToastEvent({
        title: "Error",
        message: this.OrderProcessData.errorMessage
          ? this.OrderProcessData.errorMessage
          : "Something went wrong Please report to our support.",
        variant: "error",
      });
      this.dispatchEvent(eventMessage);
    } else if (this.confirmationCount <= 3) {
      setTimeout(() => {
        this.handleConfirmationOk();
      }, 3000);
    }
    this.confirmationCount++;
  }

  fetchSalesOrderId() {
    getSalesOrderIdByOrderId({ orderId: this.OrderProcessData.orderId })
      .then((result) => {
        if (result) {
          this.OrderProcessData.isSoCreated = true;
          this.OrderProcessData.soId = result;
        }
      })
      .catch((error) => {
        this.OrderProcessData.isError = true;
        this.OrderProcessData.errorMessage = error.body.message;
      });
  }

  handleViewTaxBreakup() {
    this.isShowTaxBreakup = !this.isShowTaxBreakup;
  }
}
